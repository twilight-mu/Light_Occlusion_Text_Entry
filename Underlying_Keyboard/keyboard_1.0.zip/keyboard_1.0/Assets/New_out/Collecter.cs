using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collecter : MonoBehaviour
{
    // Start is called before the first frame update
    private Client client;
    private bool flag;
    void Start()
    {
        flag = false;
        client = new Client();
    }
    private void OnMouseDown()
    {
        Vector2 pos = Input.mousePosition;
        client.Send(pos.x+" "+pos.y);
        Debug.Log( pos.x + " " + pos.y);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
