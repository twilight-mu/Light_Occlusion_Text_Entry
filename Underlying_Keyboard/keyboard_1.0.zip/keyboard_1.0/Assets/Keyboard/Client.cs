using UnityEngine;
using UnityEngine.UI;
using System.Net;
using System.Net.Sockets;//����socket�����ռ�
using System.Threading;
using System.Text;
using UnityEngine.SceneManagement;

public class Client : MonoBehaviour
{
    void Start()
    {
        ConnectServer();
    }

    // Update is called once per frame
    void Update()
    {

    }

    /// <summary>
    /// ���ӷ�����
    /// </summary>
    static Socket socket_client;
    public void ConnectServer()
    {
        try
        {
            //IPAddress pAddress = IPAddress.Parse("192.168.137.1"); //�Լ�
            //IPAddress pAddress = IPAddress.Parse("192.168.119.8"); //����
            IPAddress pAddress = IPAddress.Parse("192.168.195.142"); //VRһ���
            IPEndPoint pEndPoint = new IPEndPoint(pAddress, 1200);
            socket_client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket_client.Connect(pEndPoint);
            Debug.Log("���ӳɹ�");
            //�����̣߳�ִ�ж�ȡ��������Ϣ
            Thread c_thread = new Thread(Received);
            c_thread.IsBackground = true;
            c_thread.Start();
        }
        catch (System.Exception)
        {
            Debug.Log("IP�˿ںŴ�����߷�����δ����");
        }
    }

    /// <summary>
    /// ��ȡ��������Ϣ
    /// </summary>
    public void Received()
    {
        while (true)
        {
            try
            {
                byte[] buffer = new byte[1024];
                int len = socket_client.Receive(buffer);
                if (len == 0) break;
                string str = Encoding.UTF8.GetString(buffer, 0, len);
                Debug.Log("�ͻ��˴�ӡ������������Ϣ��" + socket_client.RemoteEndPoint + ":" + str);
            }
            catch (System.Exception)
            {
                throw;
            }

        }
    }
    /// <summary>
    /// ������Ϣ
    /// </summary>
    /// <param name="msg"></param>
    public void Send(string msg)
    {
        try
        {
            byte[] buffer = new byte[1024];
            buffer = Encoding.UTF8.GetBytes(msg);
            socket_client.Send(buffer);
        }
        catch (System.Exception)
        {

            Debug.Log("δ����");
        }
    }
    /// <summary>
    /// �ر�����
    /// </summary>
    public void close()
    {
        try
        {
            socket_client.Close();
            Debug.Log("�رտͻ�������");
            SceneManager.LoadScene("control");
        }
        catch (System.Exception)
        {
            Debug.Log("δ����");
        }
    }
}