using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestOut : MonoBehaviour
{
    private bool flag;
    private Client client;
    public char c;
    public AudioSource play;
    // Start is called before the first frame update
    void Start()
    {
        flag = false;
        client = new Client();
        Color cl = new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);

        //Color cl = new Color(1, 1, 1);

        transform.GetComponent<MeshRenderer>().material.color = cl;
        Vector3 targetPos = Camera.main.WorldToScreenPoint(transform.position);
        Debug.Log("Point"+c+":"+ targetPos.x + " " + targetPos.y);
        //client.Send("Point" + c + ":" + targetPos.x + " " + targetPos.y);
    }
    private void OnMouseDown()
    {
        //flag = true;
        //client.Send(c.ToString());
        //play.Play();
    }
    private void OnMouseOver()
    {
        Color cl = new Color(175.0f / 255, 130.0f / 255, 130.0f / 255);
        transform.GetComponent<MeshRenderer>().material.color = cl;
        if(c==' ')
        {
            client.Send( "spaceshow");
        }
        else
        {
            client.Send(c.ToString() + "show");
        }

        if (Input.GetMouseButtonUp(0))
        {
            flag = true;
            client.Send(c.ToString());
            play.Play();
        }
    }

    private void OnMouseExit()
    {
        Color cl = new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);
        transform.GetComponent<MeshRenderer>().material.color = cl;
    }
    private void OnMouseUp()
    {

    }
    // Update is called once per frame
    void Update()
    {

        if (flag)
        {
            Debug.Log("OK "+c);
            GameObject go = GameObject.Find("Text_Entry");
            string text = go.transform.GetComponent<TextMesh>().text;
            text=text.Insert(text.Length - 1, c.ToString());
            go.transform.GetComponent<TextMesh>().text = text;
            flag = false;
        }
    }

}
