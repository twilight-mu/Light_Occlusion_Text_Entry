using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestDel : MonoBehaviour
{
    private bool flag;
    private Client client;
    public AudioSource play;
    // Start is called before the first frame update
    void Start()
    {
        flag = false;
        client = new Client();
        Color cl = new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);

        //Color cl = new Color(1, 1, 1);
        transform.GetComponent<MeshRenderer>().material.color = cl;
        Vector3 targetPos = Camera.main.WorldToScreenPoint(transform.position);
        Debug.Log("Point_DEL:" + targetPos.x + " " + targetPos.y);
        //client.Send("Point_DEL:" + targetPos.x + " " + targetPos.y);
    }
    private void OnMouseDown()
    {
        //flag = true;
        //client.Send("del");
        //play.Play();
    }
    private void OnMouseOver()
    {
        Color cl = new Color(175.0f / 255, 130.0f / 255, 130.0f / 255);
        transform.GetComponent<MeshRenderer>().material.color = cl;
        client.Send("delshow");
        if (Input.GetMouseButtonUp(0))
        {
            flag = true;
            client.Send("del");
            play.Play();
        }
    }

    private void OnMouseExit()
    {
        Color cl = new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);
        transform.GetComponent<MeshRenderer>().material.color = cl;
    }
    private void OnMouseUp()
    {

    }
    // Update is called once per frame
    void Update()
    {
        if (flag)
        {
            Debug.Log("OK Del");
            GameObject go = GameObject.Find("Text_Entry");
            string text = go.transform.GetComponent<TextMesh>().text;
            if(text.Length>7)
            {
                text = text.Remove(text.Length - 2, 1);
                go.transform.GetComponent<TextMesh>().text = text;
            }

            flag = false;
        }
    }
}
