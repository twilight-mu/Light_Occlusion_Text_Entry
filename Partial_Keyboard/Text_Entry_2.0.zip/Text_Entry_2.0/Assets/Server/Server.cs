using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;//��Ҫ����socket�����ռ�
using System.Net;
using System.Linq;
using System.Text;
using System.Threading;
using System.Text.RegularExpressions;
using System;

public class Server : MonoBehaviour
{
    // Start is called before the first frame update
    Socket socket_server;
    private bool flag;
    private bool del_flag;
    private bool sym_flag;
    private bool show_flag;
    private string[] c = new string[26] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
    private string[][] arrayc = new string[26][] { new string[3] { "N", "R", "T" }, new string[3] { "E", "A", "L" }, new string[3] { "O", "A", "E" }, new string[3] { "E", "O", "I" }, new string[3] { "R", "S", "N" }, new string[3] { "O", "I", "E" }, new string[3] { "E", "O", "H" }, new string[3] { "E", "A", "I" }, new string[3] { "N", "S", "T" }, new string[3] { "U", "E", "O" }, new string[3] { "E", "I", "S" }, new string[3] { "E", "I", "O" }, new string[3] { "E", "A", "O" }, new string[3] { "G", "T", "E" }, new string[3] { "N", "U", "R" }, new string[3] { "E", "L", "R" }, new string[3] { "U", "U", "U" }, new string[3] { "E", "I", "O" }, new string[3] { "T", "E", "I" }, new string[3] { "H", "I", "O" }, new string[3] { "R", "S", "N" }, new string[3] { "E", "I", "A" }, new string[3] { "A", "I", "E" }, new string[3] { "P", "C", "A" }, new string[3] { "O", "S", "E" }, new string[3] { "E", "A", "I" }, };
    string str;
    string cstr;
    string symstr;
    string showstr;
    void Start()
    {
        openServer();
        flag = false;
        del_flag = false;
        sym_flag = false;
        show_flag = false;
        for(int i=0;i<26;i++)
        {
            GameObject go = GameObject.Find(c[i]);
            Color cl = new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);
            go.transform.GetComponent<MeshRenderer>().material.color = cl;
            /*if (c[i] == "Q" || c[i] == "Z" || c[i] == "P" || c[i] == "M")
                continue;
            if(c[i]=="W")
            {
                cl = new Color(220.0f / 255, 99.0f / 255, 71.0f / 255);
                go.transform.GetComponent<MeshRenderer>().material.color = cl;
                continue;
            }*/
            //go.SetActive(false);
        }
        GameObject tempgo = GameObject.Find("D_show");
        Color tempcl = new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);
        tempgo.transform.GetComponent<MeshRenderer>().material.color = tempcl;
        tempgo = GameObject.Find("J_show");
        tempcl= new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);
        tempgo.transform.GetComponent<MeshRenderer>().material.color = tempcl;
    }

    // Update is called once per frame
    void Update()
    {
        if (flag)
        {
            flag = false;
            Debug.Log("OK " +cstr+" "+DateTime.Now.ToString("mm:ss.fff"));
            GameObject go = GameObject.Find("Text_Entry");
            string text = go.transform.GetComponent<TextMesh>().text;
            text = text.Insert(text.Length - 1, cstr);
            go.transform.GetComponent<TextMesh>().text = text;
            
        }
        if(del_flag)
        {
            del_flag = false;
            Debug.Log("OK Del" + " " + DateTime.Now.ToString("mm:ss.fff"));
            GameObject go = GameObject.Find("Text_Entry");
            string text = go.transform.GetComponent<TextMesh>().text;
            if (text.Length > 7)
            {
                text = text.Remove(text.Length - 2, 1);
                go.transform.GetComponent<TextMesh>().text = text;
            }
            del_flag = false;
        }
        if(sym_flag)
        {
            sym_flag = false;
            Debug.Log("OK sym" + " " + DateTime.Now.ToString("mm:ss.fff"));
            GameObject go = GameObject.Find("Text_Entry");
            string text = go.transform.GetComponent<TextMesh>().text;
            string temp1 = split(text.Substring(6, text.Length - 7));
            GameObject go1 = GameObject.Find(symstr);
            string text1 = go1.transform.GetComponent<TextMesh>().text;
            /*string temp2="";
            var regex = new Regex(@"(""((\\"")|([^""]))*"")|('((\\')|([^']))*')|(\S+)");
            var matches = regex.Matches(text.Substring(6, text.Length - 7));
            for(int i=0;i<matches.Count-1;i++)
            {
                temp2 += matches[i].ToString();
                temp2 += " ";
            }*/
            text = text.Remove(text.Length - (1+temp1.Length), temp1.Length);
            text = text.Insert(text.Length - 1,text1);
            go.transform.GetComponent<TextMesh>().text = text;
        }
        if (show_flag)
        {
            Color cl;
            GameObject parentObj = GameObject.Find("Keyboard_show");
            GameObject select_go = parentObj.transform.Find(showstr).gameObject;
            for (int i = 0; i < 26; i++)
            {
                GameObject go = parentObj.transform.Find(c[i]).gameObject;
                float dist = (select_go.transform.position - go.transform.position).magnitude;
                //Debug.Log(dist);
                if (showstr == c[i])
                {
                    cl = new Color(175.0f / 255, 130.0f / 255, 130.0f / 255);
                    go.transform.GetComponent<MeshRenderer>().material.color = cl;
                }
                else
                {
                    //cl = new Color(220.0f / 255, 100.0f / 255, 71.0f / 255);
                    cl = new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);
                    go.transform.GetComponent<MeshRenderer>().material.color = cl;
                }

                if (dist<1.5)
                {
                    go.SetActive(true);
                }
                else
                {
                    go.SetActive(false);
                }
            }
            /*char[] tempc = showstr.ToCharArray();
            GameObject tempgo = parentObj.transform.Find(arrayc[tempc[0] - 'A'][2]).gameObject;
            tempgo.SetActive(true);
            cl = new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);
            tempgo.transform.GetComponent<MeshRenderer>().material.color = cl;
            tempgo = parentObj.transform.Find(arrayc[tempc[0] - 'A'][1]).gameObject;
            tempgo.SetActive(true);
            cl = new Color(255.0f / 255, 97.0f / 255, 3.0f / 255);
            tempgo.transform.GetComponent<MeshRenderer>().material.color = cl;
            tempgo = parentObj.transform.Find(arrayc[tempc[0] - 'A'][0]).gameObject;
            tempgo.SetActive(true);
            cl = new Color(65.0f / 255, 105.0f / 255, 225.0f / 255);
            tempgo.transform.GetComponent<MeshRenderer>().material.color = cl;*/
            show_flag = false;
        }
    }
    private void OnDestroy()
    {
        socket_server.Close();
        Debug.Log("���ӹر�");
    }

    /// <summary>
    /// ������
    /// </summary>
    void openServer()
    {
        try
        {
            IPAddress pAddress = IPAddress.Any;
            IPEndPoint pEndPoint = new IPEndPoint(pAddress, 1200);
            socket_server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket_server.Bind(pEndPoint);
            socket_server.Listen(5);//�������������
            Debug.Log("�����ɹ�");
            //�������߳�ִ�м��������������UI������unity����Ӧ
            Thread thread = new Thread(listen);
            thread.IsBackground = true;
            thread.Start(socket_server);
        }
        catch (System.Exception)
        {
            throw;
        }
    }
    /// <summary>
    /// ����
    /// </summary>
    Socket socketSend;
    void listen(object o)
    {
        try
        {
            Socket socketWatch = o as Socket;
            while (true)
            {
                socketSend = socketWatch.Accept();
                Debug.Log(socketSend.RemoteEndPoint.ToString() + ":" + "���ӳɹ�");

                Thread r_thread = new Thread(Received);
                r_thread.IsBackground = true;
                r_thread.Start(socketSend);
            }
        }
        catch (System.Exception)
        {

            throw;
        }
    }
    /// <summary>
    /// ��ȡ��Ϣ
    /// </summary>
    /// <param name="o"></param>
    void Received(object o)
    {
        try
        {
            Socket socketSend = o as Socket;
            while (true)
            {
                byte[] buffer = new byte[1024];
                int len = socketSend.Receive(buffer);
                if (len == 0) break;
                str = Encoding.UTF8.GetString(buffer, 0, len);
                Debug.Log("��������ӡ�ͻ��˷�����Ϣ��" + socketSend.RemoteEndPoint + ":" + str);
                if (str == "del")
                {
                    Send("��ɾ��");
                    del_flag = true;
                }
                else if (str == "word1" || str == "word2" || str == "word3")
                {
                    Send("���滻");
                    symstr = str;
                    sym_flag = true;
                }
                else if (str == "a" || str == "b"|| str == "c"|| str == "d"|| str == "e"|| str == "f"|| str == "g"|| str == "h"|| str == "i"|| str == "j"|| str == "k"|| str == "l"|| str == "m"|| str == "n"|| str == "o"|| str == "p"|| str == "q"|| str == "r"|| str == "s"|| str == "t"|| str == "u"|| str == "v"|| str == "w"|| str == "x"|| str == "y"|| str == "z"|| str == " ")
                {
                    Send("���յ���"+str);
                    cstr = str;
                    flag = true;
                }
                else
                {
                    Send("��show");
                    string temp=str.Remove(1, 4);
                    showstr = temp.ToUpper();
                    show_flag = true;
                }
            }
        }
        catch (System.Exception)
        {
            throw;
        }
    }
    /// <summary>
    /// ������Ϣ
    /// </summary>
    /// <param name="msg"></param>
    void Send(string msg)
    {
        byte[] buffer = Encoding.UTF8.GetBytes(msg);
        socketSend.Send(buffer);
    }
    string split(string input)
    {
        var regex = new Regex(@"(""((\\"")|([^""]))*"")|('((\\')|([^']))*')|(\S+)");
        var matches = regex.Matches(input);
        //foreach (Match match in matches)
        //{
        //    Console.WriteLine(match);
        //}
        if (matches.Count == 0)
        {
            return "";
        }
        else
        {
            return matches[matches.Count - 1].ToString();
        }
    }
}