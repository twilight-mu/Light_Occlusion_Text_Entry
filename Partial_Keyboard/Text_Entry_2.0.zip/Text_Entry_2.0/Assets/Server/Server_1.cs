using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;//��Ҫ����socket�����ռ�
using System.Net;
using System.Linq;
using System.Text;
using System.Threading;
using System.Text.RegularExpressions;
using System;

public class Server_1 : MonoBehaviour
{
    // Start is called before the first frame update
    Socket socket_server;
    private bool flag;
    private bool del_flag;
    private bool sym_flag;
    private bool show_flag;
    private string[] c = new string[7] { "Cen", "L1", "R1", "L2", "R2", "L3", "R3"};
    private string[] word = new string[26] { "AQW S Z", "BGHVN  ", "CDFXV  ", "DERSFXC", "E  WRSD", "FRTDGCV", "GTYFHVB", "HYUGJBN", "I  UOJK", "JUIHKNM", "KIOJLM ", "LOPK   ", "MJKN   ", "NHJBM  ", "O  IPKL", "P  O L ", "Q   W A", "R  ETDF", "SWEADZX", "T  RYFG", "U  YIHJ", "VFGCB  ", "W  QEAS", "XSDZC  ", "Y  TUGH", "ZAS X  " };
    string str;
    string cstr;
    string symstr;
    string showstr;
    void Start()
    {
        openServer();
        flag = false;
        del_flag = false;
        sym_flag = false;
        show_flag = false;
        for (int i = 0; i < 7; i++)
        {
            GameObject go = GameObject.Find(c[i]);
            Color cl = new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);
            go.transform.GetComponent<MeshRenderer>().material.color = cl;
            //go.SetActive(false);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (flag)
        {
            flag = false;
            Debug.Log("OK " + cstr + " " + DateTime.Now.ToString("mm:ss.fff"));
            GameObject go = GameObject.Find("Text_Entry");
            string text = go.transform.GetComponent<TextMesh>().text;
            text = text.Insert(text.Length - 1, cstr);
            go.transform.GetComponent<TextMesh>().text = text;

        }
        if (del_flag)
        {
            del_flag = false;
            Debug.Log("OK Del" + " " + DateTime.Now.ToString("mm:ss.fff"));
            GameObject go = GameObject.Find("Text_Entry");
            string text = go.transform.GetComponent<TextMesh>().text;
            if (text.Length > 7)
            {
                text = text.Remove(text.Length - 2, 1);
                go.transform.GetComponent<TextMesh>().text = text;
            }
            del_flag = false;
        }
        if (sym_flag)
        {
            sym_flag = false;
            Debug.Log("OK sym" + " " + DateTime.Now.ToString("mm:ss.fff"));
            GameObject go = GameObject.Find("Text_Entry");
            string text = go.transform.GetComponent<TextMesh>().text;
            string temp1 = split(text.Substring(6, text.Length - 7));
            GameObject go1 = GameObject.Find(symstr);
            string text1 = go1.transform.GetComponent<TextMesh>().text;
            /*string temp2="";
            var regex = new Regex(@"(""((\\"")|([^""]))*"")|('((\\')|([^']))*')|(\S+)");
            var matches = regex.Matches(text.Substring(6, text.Length - 7));
            for(int i=0;i<matches.Count-1;i++)
            {
                temp2 += matches[i].ToString();
                temp2 += " ";
            }*/
            text = text.Remove(text.Length - (1 + temp1.Length), temp1.Length);
            text = text.Insert(text.Length - 1, text1);
            go.transform.GetComponent<TextMesh>().text = text;
        }
        if (show_flag)
        {
            Color cl;
            //GameObject parentObj = GameObject.Find("Keyboard_show (1)");
            //GameObject select_go = parentObj.transform.Find(showstr).gameObject;
            for (int i = 0; i < 26; i++)
            {
                char[] temp = word[i].ToCharArray();
                if(temp[0].ToString()==showstr)
                {
                    for(int j=0;j<7;j++)
                    {
                        GameObject go = GameObject.Find(c[j]);
                        GameObject go_text = go.transform.Find("New Text").gameObject;
                        if(j==0)
                            cl = new Color(175.0f / 255, 130.0f / 255, 130.0f / 255);
                        else
                            cl = new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);
                        go.transform.GetComponent<MeshRenderer>().material.color = cl;
                        go_text.transform.GetComponent<TextMesh>().text = temp[j].ToString();
                    }
                    break;
                }
            }
            show_flag = false;
        }
    }
    private void OnDestroy()
    {
        socket_server.Close();
        Debug.Log("���ӹر�");
    }

    /// <summary>
    /// ������
    /// </summary>
    void openServer()
    {
        try
        {
            IPAddress pAddress = IPAddress.Any;
            IPEndPoint pEndPoint = new IPEndPoint(pAddress, 1200);
            socket_server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket_server.Bind(pEndPoint);
            socket_server.Listen(5);//�������������
            Debug.Log("�����ɹ�");
            //�������߳�ִ�м��������������UI������unity����Ӧ
            Thread thread = new Thread(listen);
            thread.IsBackground = true;
            thread.Start(socket_server);
        }
        catch (System.Exception)
        {
            throw;
        }
    }
    /// <summary>
    /// ����
    /// </summary>
    Socket socketSend;
    void listen(object o)
    {
        try
        {
            Socket socketWatch = o as Socket;
            while (true)
            {
                socketSend = socketWatch.Accept();
                Debug.Log(socketSend.RemoteEndPoint.ToString() + ":" + "���ӳɹ�");

                Thread r_thread = new Thread(Received);
                r_thread.IsBackground = true;
                r_thread.Start(socketSend);
            }
        }
        catch (System.Exception)
        {

            throw;
        }
    }
    /// <summary>
    /// ��ȡ��Ϣ
    /// </summary>
    /// <param name="o"></param>
    void Received(object o)
    {
        try
        {
            Socket socketSend = o as Socket;
            while (true)
            {
                byte[] buffer = new byte[1024];
                int len = socketSend.Receive(buffer);
                if (len == 0) break;
                str = Encoding.UTF8.GetString(buffer, 0, len);
                Debug.Log("��������ӡ�ͻ��˷�����Ϣ��" + socketSend.RemoteEndPoint + ":" + str);
                if (str == "del")
                {
                    Send("��ɾ��");
                    del_flag = true;
                }
                else if (str == "word1" || str == "word2" || str == "word3")
                {
                    Send("���滻");
                    symstr = str;
                    sym_flag = true;
                }
                else if (str == "a" || str == "b" || str == "c" || str == "d" || str == "e" || str == "f" || str == "g" || str == "h" || str == "i" || str == "j" || str == "k" || str == "l" || str == "m" || str == "n" || str == "o" || str == "p" || str == "q" || str == "r" || str == "s" || str == "t" || str == "u" || str == "v" || str == "w" || str == "x" || str == "y" || str == "z" || str == " ")
                {
                    Send("���յ���" + str);
                    cstr = str;
                    flag = true;
                }
                else
                {
                    Send("��show");
                    string temp = str.Remove(1, 4);
                    showstr = temp.ToUpper();
                    show_flag = true;
                }
            }
        }
        catch (System.Exception)
        {
            throw;
        }
    }
    /// <summary>
    /// ������Ϣ
    /// </summary>
    /// <param name="msg"></param>
    void Send(string msg)
    {
        byte[] buffer = Encoding.UTF8.GetBytes(msg);
        socketSend.Send(buffer);
    }
    string split(string input)
    {
        var regex = new Regex(@"(""((\\"")|([^""]))*"")|('((\\')|([^']))*')|(\S+)");
        var matches = regex.Matches(input);
        //foreach (Match match in matches)
        //{
        //    Console.WriteLine(match);
        //}
        if (matches.Count == 0)
        {
            return "";
        }
        else
        {
            return matches[matches.Count - 1].ToString();
        }
    }
}