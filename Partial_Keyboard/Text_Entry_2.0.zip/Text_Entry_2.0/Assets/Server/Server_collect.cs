using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net.Sockets;//��Ҫ����socket�����ռ�
using System.Net;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;

public class Server_collect : MonoBehaviour
{
    // Start is called before the first frame update
    Socket socket_server;
    void Start()
    {
        openServer();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    /// <summary>
    /// ������
    /// </summary>
    void openServer()
    {
        try
        {
            IPAddress pAddress = IPAddress.Any;
            IPEndPoint pEndPoint = new IPEndPoint(pAddress, 80);
            socket_server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket_server.Bind(pEndPoint);
            socket_server.Listen(5);//�������������
            Debug.Log("�����ɹ�");
            //�������߳�ִ�м��������������UI������unity����Ӧ
            Thread thread = new Thread(listen);
            thread.IsBackground = true;
            thread.Start(socket_server);
        }
        catch (System.Exception)
        {

            throw;
        }
    }
    /// <summary>
    /// ����
    /// </summary>
    Socket socketSend;
    void listen(object o)
    {
        try
        {
            Socket socketWatch = o as Socket;
            while (true)
            {
                socketSend = socketWatch.Accept();
                Debug.Log(socketSend.RemoteEndPoint.ToString() + ":" + "���ӳɹ�");

                Thread r_thread = new Thread(Received);
                r_thread.IsBackground = true;
                r_thread.Start(socketSend);
            }
        }
        catch (System.Exception)
        {

            throw;
        }
    }
    /// <summary>
    /// ��ȡ��Ϣ
    /// </summary>
    /// <param name="o"></param>
    void Received(object o)
    {
        try
        {
            Socket socketSend = o as Socket;
            while (true)
            {
                byte[] buffer = new byte[1024];
                int len = socketSend.Receive(buffer);
                if (len == 0) break;
                string str = Encoding.UTF8.GetString(buffer, 0, len);
                WriteText(str);
                Debug.Log("��������ӡ�ͻ��˷�����Ϣ��" + socketSend.RemoteEndPoint + ":" + str);
                Send("���յ���");
            }
        }
        catch (System.Exception)
        {

            throw;
        }
    }
    /// <summary>
    /// ������Ϣ
    /// </summary>
    /// <param name="msg"></param>
    void Send(string msg)
    {
        byte[] buffer = Encoding.UTF8.GetBytes(msg);
        socketSend.Send(buffer);
    }
    //дtxt�ļ�
    public static void WriteText(string TempSTR)
    {
            //FileStream fs = new FileStream("C:/Users/Twilight/Desktop/num.txt", FileMode.Open, FileAccess.Write);
            StreamWriter sw = File.AppendText("C:/Users/Twilight/Desktop/num.txt");
            //��ʼд��  
            sw.WriteLine(TempSTR);
            //��ջ�����  
            sw.Flush();
            //�ر���  
            sw.Close();
            //fs.Close();
        
    }

}
