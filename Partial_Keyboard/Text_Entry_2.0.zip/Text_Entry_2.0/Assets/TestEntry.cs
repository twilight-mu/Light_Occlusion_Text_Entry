using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class TestEntry: MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {
        /*GameObject go = GameObject.Find(c[i]);
        Color cl = new Color(175.0f / 255, 30.0f / 255, 30.0f / 255);
        go.transform.GetComponent<MeshRenderer>().material.shader = Shader_Test;*/
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        GameObject go = GameObject.Find("Text_Entry");
        string text= go.transform.GetComponent<TextMesh>().text;
        StringBuilder temp = new StringBuilder(text);
        if (text[text.Length-1]=='_')
        {
            //text=text.Replace('_',' ');
            temp.Replace('_', ' ', text.Length - 1, 1);
            text = temp.ToString();
            go.transform.GetComponent<TextMesh>().text = text;
        }
        else
        {
            //text=text.Replace(' ', '_');
            temp.Replace(' ', '_', text.Length - 1, 1);
            text = temp.ToString();
            go.transform.GetComponent<TextMesh>().text = text;
        }
        //Debug.Log("����1��");
    }
}
