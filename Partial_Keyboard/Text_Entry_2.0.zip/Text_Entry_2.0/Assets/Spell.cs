using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

public class Spell : MonoBehaviour
{
    // Start is called before the first frame update
    private string input;
    private SymSpell symSpell;
    private Server server;
    void Start()
    {
        long memSize = GC.GetTotalMemory(true);
        Stopwatch stopWatch = new Stopwatch();
        stopWatch.Start();
        server = new Server();
        //set parameters
        const int initialCapacity = 82765;
        const int maxEditDistance = 2;
        const int prefixLength = 7;
        symSpell = new SymSpell(initialCapacity, maxEditDistance, prefixLength);

        //Load a frequency dictionary
        //wordfrequency_en.txt  ensures high correction quality by combining two data sources: 
        //Google Books Ngram data  provides representative word frequencies (but contains many entries with spelling errors)  
        //SCOWL �� Spell Checker Oriented Word Lists which ensures genuine English vocabulary (but contained no word frequencies)   
        //string path ="D:/Unity/pk/Text_Entry_2.0/Assets/SymSpell/frequency_dictionary_en_82_765.txt"; //path referencing the SymSpell core project
        //string path = "../../frequency_dictionary_en_82_765.txt";  //path when using symspell nuget package (frequency_dictionary_en_82_765.txt is included in nuget package)
        string path = "./Assets/SymSpell/frequency_dictionary_en_82_765.txt";
        if (!symSpell.LoadDictionary(path, 0, 1)) 
        { UnityEngine.Debug.Log("\rFile not found: " + Path.GetFullPath(path)); }

        //Alternatively Create the dictionary from a text corpus (e.g. http://norvig.com/big.txt ) 
        //Make sure the corpus does not contain spelling errors, invalid terms and the word frequency is representative to increase the precision of the spelling correction.
        //You may use SymSpell.CreateDictionaryEntry() to update a (self learning) dictionary incrementally
        //To extend spelling correction beyond single words to phrases (e.g. correcting "unitedkingom" to "united kingdom") simply add those phrases with CreateDictionaryEntry(). or use  https://github.com/wolfgarbe/SymSpellCompound
        //string path = "big.txt";
        //if (!symSpell.CreateDictionary(path)) Console.Error.WriteLine("File not found: " + Path.GetFullPath(path));

        stopWatch.Stop();
        long memDelta = GC.GetTotalMemory(true) - memSize;
        UnityEngine.Debug.Log("\rDictionary: " + symSpell.WordCount.ToString("N0") + " words, "
            + symSpell.EntryCount.ToString("N0") + " entries, edit distance=" + symSpell.MaxDictionaryEditDistance.ToString()
            + " in " + stopWatch.Elapsed.TotalMilliseconds.ToString("0.0") + "ms "
            + (memDelta / 1024 / 1024.0).ToString("N0") + " MB");

        //warm up
        var result = symSpell.Lookup("warmup", SymSpell.Verbosity.All);
    }

    // Update is called once per frame
    void Update()
    {
        GameObject go = GameObject.Find("Text_Entry");
        string text = go.transform.GetComponent<TextMesh>().text;
        string temp1 = text.Substring(6,text.Length-7);
        //UnityEngine.Debug.Log(temp1);
        //temp[0];
        Correct(split(temp1), symSpell);
    }

    void Correct(string input, SymSpell symSpell)
    {
        List<SymSpell.SuggestItem> suggestions = null;

        Stopwatch stopWatch = new Stopwatch();
        stopWatch.Start();

        //check if input term or similar terms within edit-distance are in dictionary, return results sorted by ascending edit distance, then by descending word frequency     
        const SymSpell.Verbosity verbosity = SymSpell.Verbosity.Closest;
        suggestions = symSpell.Lookup(input, verbosity);

        stopWatch.Stop();
        Console.WriteLine(stopWatch.Elapsed.TotalMilliseconds.ToString("0.000") + " ms");

        //display term and frequency
        int num = suggestions.Count;
        if(num>=3)
        {
            //UnityEngine.Debug.Log("OK " + suggestions[0].term);
            GameObject go1 = GameObject.Find("word1");
            go1.transform.GetComponent<TextMesh>().text = suggestions[0].term;
            //UnityEngine.Debug.Log("OK " + suggestions[1].term);
            GameObject go2 = GameObject.Find("word2");
            go2.transform.GetComponent<TextMesh>().text = suggestions[1].term;
            //UnityEngine.Debug.Log("OK " + suggestions[2].term);
            GameObject go3 = GameObject.Find("word3");
            go3.transform.GetComponent<TextMesh>().text = suggestions[2].term;
        }
        else if(num==2)
        {
            //UnityEngine.Debug.Log("OK " + suggestions[0].term);
            GameObject go1 = GameObject.Find("word1");
            go1.transform.GetComponent<TextMesh>().text = suggestions[0].term;
            //UnityEngine.Debug.Log("OK " + suggestions[1].term);
            GameObject go2 = GameObject.Find("word2");
            go2.transform.GetComponent<TextMesh>().text = suggestions[1].term;
            //UnityEngine.Debug.Log("OK " + suggestions[2].term);
            GameObject go3 = GameObject.Find("word3");
            go3.transform.GetComponent<TextMesh>().text =" ";
        }
        else if(num==1)
        {
            //UnityEngine.Debug.Log("OK " + suggestions[0].term);
            GameObject go1 = GameObject.Find("word1");
            go1.transform.GetComponent<TextMesh>().text = suggestions[0].term;
            //UnityEngine.Debug.Log("OK " + suggestions[1].term);
            GameObject go2 = GameObject.Find("word2");
            go2.transform.GetComponent<TextMesh>().text = " ";
            //UnityEngine.Debug.Log("OK " + suggestions[2].term);
            GameObject go3 = GameObject.Find("word3");
            go3.transform.GetComponent<TextMesh>().text = " ";
        }
        else if(num==0)
        {
            //UnityEngine.Debug.Log("OK " + suggestions[0].term);
            GameObject go1 = GameObject.Find("word1");
            go1.transform.GetComponent<TextMesh>().text =" ";
            //UnityEngine.Debug.Log("OK " + suggestions[1].term);
            GameObject go2 = GameObject.Find("word2");
            go2.transform.GetComponent<TextMesh>().text = " ";
            //UnityEngine.Debug.Log("OK " + suggestions[2].term);
            GameObject go3 = GameObject.Find("word3");
            go3.transform.GetComponent<TextMesh>().text = " ";
        }
        //foreach (var suggestion in suggestions)
        //{
        //    Console.WriteLine(suggestion.term + " " + suggestion.distance.ToString() + " " + suggestion.count.ToString("N0"));
        //}
        //if (verbosity != SymSpell.Verbosity.Top) 
        //    Console.WriteLine(suggestions.Count.ToString() + " suggestions");
    }
    string split(string input)
    {
        var regex = new Regex(@"(""((\\"")|([^""]))*"")|('((\\')|([^']))*')|(\S+)");
        var matches = regex.Matches(input);
        //foreach (Match match in matches)
        //{
        //    Console.WriteLine(match);
        //}
        if(matches.Count==0)
        {
            return "";
        }
        else
        {
            return matches[matches.Count - 1].ToString();
        }
    }
}
